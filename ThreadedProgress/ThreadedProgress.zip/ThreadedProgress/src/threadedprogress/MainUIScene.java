/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threadedprogress;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.stage.WindowEvent;
import ui.UIScene;

/**
 * FXML Controller class
 *
 * @author dalemusser
 */
public class MainUIScene extends UIScene {
    
    @FXML
    private Label currentValueLabel;
    
    @FXML
    private Label percentageCompleteLabel;
    
    @FXML
    private Label statusLabel;
    
    @FXML
    private ProgressBar progressBar;
    
    private Counter counter;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    
    @Override
    public void onClose(WindowEvent we) {
        if (counter != null) {
            counter.interrupt();
        }

        //we.consume(); - keep from closing
    }
    
    @FXML
    public void start(ActionEvent event) {
        if (counter != null) return;
        
        progressBar.setProgress(0);
        
        counter = new Counter(0, 50);
        counter.setOnNotification((percentComplete, currentVal, status) -> {
            currentValueLabel.setText(Integer.toString(currentVal));
            percentageCompleteLabel.setText(Double.toString(percentComplete));
            statusLabel.setText(status.toString());
            progressBar.setProgress(percentComplete);
            if (status == Status.FINISHED || status == Status.STOPPED) {
                counter = null;
            }
        });
        counter.start();
        
    }
    
    @FXML
    public void stop(ActionEvent event) {
        if (counter == null) return;
        counter.interrupt();
    }
    
}
