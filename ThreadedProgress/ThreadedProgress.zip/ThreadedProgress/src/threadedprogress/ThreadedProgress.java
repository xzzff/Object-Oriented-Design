/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threadedprogress;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import ui.UIScene;
import ui.UIStage;

/**
 *
 * @author dalemusser
 */
public class ThreadedProgress extends Application {
    
    private UIStage mainUIStage;
    private UIScene mainUIScene;
    
    @Override
    public void start(Stage stage) throws Exception {
        mainUIStage = new UIStage(stage);
        
        try {
            mainUIScene = mainUIStage.loadScene("MainUI", getClass().getResource("MainUI.fxml"));
        } catch (Exception ex) {
            System.out.println("error loading scene occurred");
        }
        mainUIStage.displayScene(mainUIScene);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
