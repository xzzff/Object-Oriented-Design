/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threadedprogress;

import javafx.application.Platform;

/**
 *
 * @author dalemusser
 */
public class Counter extends Thread {
    
    private int startVal = 0;
    private int stopVal = 0;
    private int range = 0;
    private int currentVal = 0;
    private Status status;
    
    private Notification notification;
    
    public Counter(int startVal, int stopVal) {
        this.startVal = startVal;
        this.stopVal = stopVal;
        this.range = stopVal - startVal;
        this.currentVal = startVal;
        status = Status.NOTSTARTED;
    }
    
    @Override
    public void run() {
        status = Status.RUNNING;
        
        while(currentVal < stopVal) {
            if (Thread.interrupted()) {
                onInterrupted();
                return;
            }
            
            currentVal++;
            doNotify();
            
            try {
                Thread.sleep(100);
            } catch(InterruptedException ex) {
                onInterrupted();
                return;
            }
        }
        onFinished();
    }
    
    private void onInterrupted() {
        status = Status.STOPPED;
        doNotify();
    }
    
    private void onFinished() {
        status = Status.FINISHED;
        doNotify();
    }
    
    public void setOnNotification(Notification notification) {
        this.notification = notification;
    }
    
    private void doNotify() {
        if (notification != null) {
            double percentComplete = (double)(currentVal - startVal) / (double)range;
            Platform.runLater(() -> {
                notification.handle(percentComplete, currentVal, status);
            });
        }
    }
}
